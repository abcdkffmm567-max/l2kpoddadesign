L2K TOP UP STORE - MULTI PAGE WEBSITE
=====================================

Included:
- index.html          Main landing page matching the supplied NOVA-style reference
- topup.html          Game top-up products + WhatsApp order modal
- cards.html          Digital cards page
- designs.html        Graphic design services
- services.html       Services page
- contact.html        Contact / WhatsApp page
- about.html          About page
- terms.html          Terms page
- privacy.html        Privacy page
- admin.html          Front-end demo admin panel
- css/style.css       Full responsive styling
- js/app.js           Store logic
- js/admin.js         Demo admin controls
- assets/logo.svg     L2K logo

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in Chrome/Edge/Opera, or use VS Code + Live Server.
3. No Node.js is required.

ADMIN DEMO
Username: admin
Password: l2k123

The admin page uses browser localStorage, so price/update changes are stored only in that browser.
For a real online store with Google login, real payments, real orders, shared admin access and database storage,
connect the same UI to Firebase/Supabase/a backend before publishing.

IMPORTANT
- Change the WhatsApp number in Admin before using it publicly.
- Replace sample prices/products with your actual prices.
- The site is inspired by the visual layout in the supplied screenshot, but uses original HTML/CSS artwork rather than copying proprietary site code/assets.


UPDATED: Reference-style Why Choose Us, Reseller Program and Ready CTA sections added. Admin now has Hero Background Banner upload; the selected banner appears behind L2K TOP UP on Home.
